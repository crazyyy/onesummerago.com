			<select class="widget_selector">
				<option value="rich_text">Rich Text</option>
				<option value="divider_line">Divider Line</option>
				<option value="divider_empty">Margin Bottom</option>
			</select>