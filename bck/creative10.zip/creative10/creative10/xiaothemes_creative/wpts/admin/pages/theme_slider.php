<?php
$options = array(
	
	array(
		"name" => "Slider Manager",
		"type" => "title",
		"color" => "blue"
	),

	/*MARK*/
);
return array(
	'auto' => true,
	'name' => 'slider',
	'options' => $options
);