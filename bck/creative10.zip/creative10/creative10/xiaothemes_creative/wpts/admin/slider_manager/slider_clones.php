		<div id="slider-clone">
		<div class="slider-wrap">
			<div class="slider">
				<input type="hidden" class="parent" name="">
							<input type="hidden" class="slider-id" value="" name="">
							<select name="" class="type">
								<option value="0">WOW Slider - Blast Effect</option>
							</select>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" onblur="if(this.value == '') this.value = 'Slider Name';" onfocus="if(this.value == 'Slider Name') this.value = '';" value="Slider Name" class="name" name="" />
							
							<a class="edit" href="#"><img title="Edit" alt="Edit" src="<?php echo get_template_directory_uri(); ?>/wpts/admin/css/images/pencil.png"></a>
							<a class="deleted" href="#"><img title="Delete" alt="Delete" src="<?php echo get_template_directory_uri(); ?>/wpts/admin/css/images/reclycle.png"></a>
			</div> <!-- slider -->
						<div class="slides">
										
						</div> <!-- slides -->
						<div class="add_new_slide" title=""><a href="#">ADD NEW SLIDE</a></div>
		</div>
		</div>