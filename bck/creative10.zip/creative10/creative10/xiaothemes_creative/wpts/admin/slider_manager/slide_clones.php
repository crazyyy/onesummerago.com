
	<!--- WOW SLIDER ALL TYPES --->

<div class="slide-clone slide-0">
	<div class="slide-single setting-block">
												<a href="#" class="delete-single">X</a>
												<div class="wpts_input">
													<label>Image</label>
													<input type="text" class="upload-admin-input field-1" name="sliders[][3][][0]" value="" /> <input class="upload-admin" type="button" value="Upload Image" />
												<div class="clearboth"></div>
												</div>
												<div class="wpts_input">
													<label>Thumbnail</label>
													<input type="text" class="upload-admin-input field-2" name="sliders[][3][][1]" value="" /> <input class="upload-admin" type="button" value="Upload Image" />
												<div class="clearboth"></div>
												</div>
											</div>
</div>

<!--- #END - WOW SLIDER ALL TYPES --->
