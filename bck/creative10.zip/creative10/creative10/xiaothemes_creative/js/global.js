/*  
	-------------------------------------------------------------
	Custom Javascripts - Project: Creative Single Page Portfolio
	Description: Html / Css / jQuery template
	Author: pezflash - http://www.themeforest.net/user/pezflash
	Version: 1.0
    -------------------------------------------------------------
*/



//////////////////////////////////////////////////////
//DOCUMENT READY



