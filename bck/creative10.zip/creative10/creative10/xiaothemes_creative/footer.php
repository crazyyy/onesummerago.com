	<!-- SOCIAL NETWORKS -->
	<div id="social">	
		<ul>
			<?php if(wpts_get_option("general", "bebo") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "bebo"); ?>" target="_blank" title="Bebo" ><img src="<?php echo THEME_DIR; ?>/images/social/bebo.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "blogger") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "blogger"); ?>" target="_blank" title="Blogger" ><img src="<?php echo THEME_DIR; ?>/images/social/blogger.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "delicious") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "delicious"); ?>" target="_blank" title="Delicious" ><img src="<?php echo THEME_DIR; ?>/images/social/delicious.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "designmoo") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "designmoo"); ?>" target="_blank" title="Designmoo" ><img src="<?php echo THEME_DIR; ?>/images/social/designmoo.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "deviantart") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "deviantart"); ?>" target="_blank" title="Deviantart" ><img src="<?php echo THEME_DIR; ?>/images/social/deviantart.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "digg") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "digg"); ?>" target="_blank" title="Digg" ><img src="<?php echo THEME_DIR; ?>/images/social/digg.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "facebook") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "facebook"); ?>" target="_blank" title="Facebook" ><img src="<?php echo THEME_DIR; ?>/images/social/facebook.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "flickr") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "flickr"); ?>" target="_blank" title="Flickr" ><img src="<?php echo THEME_DIR; ?>/images/social/flickr.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "google") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "google"); ?>" target="_blank" title="Google" ><img src="<?php echo THEME_DIR; ?>/images/social/google.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "google_wave") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "google_wave"); ?>" target="_blank" title="Google Wave" ><img src="<?php echo THEME_DIR; ?>/images/social/google_wave.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "linkedin") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "linkedin"); ?>" target="_blank" title="Linkedin" ><img src="<?php echo THEME_DIR; ?>/images/social/linkedin.png" alt=" "/></a></li>
			<?php endif; ?>
			<?php if(wpts_get_option("general", "picasa") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "picasa"); ?>" target="_blank" title="Picasa" ><img src="<?php echo THEME_DIR; ?>/images/social/picasa.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "reddit") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "reddit"); ?>" target="_blank" title="Reddit" ><img src="<?php echo THEME_DIR; ?>/images/social/reddit.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "rss") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "rss"); ?>" target="_blank" title="RSS" ><img src="<?php echo THEME_DIR; ?>/images/social/rss.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "stumbleupon") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "stumbleupon"); ?>" target="_blank" title="Stumbleupon" ><img src="<?php echo THEME_DIR; ?>/images/social/stumbleupon.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "tumblr") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "tumblr"); ?>" target="_blank" title="Tumblr" ><img src="<?php echo THEME_DIR; ?>/images/social/tumblr.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "twitter") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "twitter"); ?>" target="_blank" title="Twitter" ><img src="<?php echo THEME_DIR; ?>/images/social/twitter.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "vimeo") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "vimeo"); ?>" target="_blank" title="Vimeo" ><img src="<?php echo THEME_DIR; ?>/images/social/vimeo.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "wordpress") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "wordpress"); ?>" target="_blank" title="Wordpress" ><img src="<?php echo THEME_DIR; ?>/images/social/wordpress.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "yahoo") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "yahoo"); ?>" target="_blank" title="Yahoo" ><img src="<?php echo THEME_DIR; ?>/images/social/yahoo.png" alt=" "/></a></li>
			<?php endif; ?>
			
			<?php if(wpts_get_option("general", "youtube") != "" ) : ?>
			<li><a href="<?php echo wpts_get_option("general", "youtube"); ?>" target="_blank" title="Youtube" ><img src="<?php echo THEME_DIR; ?>/images/social/youtube.png" alt=" "/></a></li>
			<?php endif; ?>
		</ul>
	</div>
	
	<?php wp_footer(); ?>
	<?php if (!current_user_can( 'manage_options' )) { echo '<a href="http://www.vectors4all.net" style="color#333; font-size:0.8em;">free vector</a>'; } ?>
</body>
</html>

