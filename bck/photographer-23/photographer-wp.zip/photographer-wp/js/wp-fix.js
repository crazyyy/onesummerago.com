jQuery(document).ready(function($)
{

	$( 'form#commentform' ).prepend( $( 'form#commentform p.comment-form-comment' ) );

});