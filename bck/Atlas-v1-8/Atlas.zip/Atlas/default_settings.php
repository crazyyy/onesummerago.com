<?php
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(597, 0, 'pp_menu_style', 'grediant', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(599, 0, 'pp_font', 'Marketing_Script_400.font', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(600, 0, 'pp_h1_size', '40', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(601, 0, 'pp_h2_size', '32', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(602, 0, 'pp_h3_size', '26', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(603, 0, 'pp_h4_size', '24', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(604, 0, 'pp_h5_size', '22', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(605, 0, 'pp_h6_size', '18', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(606, 0, 'pp_menu_font_size', '11', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(607, 0, 'pp_font_color', '#cccccc', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(608, 0, 'pp_link_color', '#ffffff', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(609, 0, 'pp_hover_link_color', '#bdbdbd', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(610, 0, 'pp_h1_font_color', '#ffffff', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(611, 0, 'pp_button_bg_color', '#0563a2', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(612, 0, 'pp_button_font_color', '#ffffff', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(613, 0, 'pp_button_border_color', '#0563a2', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(614, 0, 'pp_homepage_style', 'f', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(616, 0, 'pp_slideshow_timer', '5', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(617, 0, 'pp_homepage_slideshow_sort', 'DESC', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(621, 0, 'pp_contact_thankyou', 'Thank you! We will get back to you as soon as possible', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(622, 0, 'pp_contact_form', 's:42:\"a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}\";', 'yes');");
$wpdb->query("INSERT IGNORE INTO `wp_options` VALUES(624, 0, 'pp_contact_form_sort_data', 's:42:\"a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}\";', 'yes');");

?>