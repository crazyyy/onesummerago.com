<div id="vkapi_comments">
    <?php do_action('vkapi_comments_template') ?>
</div>